# Clean-Memory-Limpa-Ram
IMPORTANT!!!
Você precisa ser root!
You need run as root!

OBS: Os dois arquivos são equivalentes, copie ou execute o que preferir!
NOTE: The two files are equivalent, copy or run whichever you prefer!

Portugues:
	Antes de tudo de permissão de execução ao arquivo
	sudo chmod +x clean_memory.sh

	depois copie o arquivo para pasta /usr/sbin/

	agora pode abrir o seu terminal e digitar o nome do arquivo e dar enter, tudo funcionando

English:
	First of all, execute permission to the file
	sudo chmod +x clean_memory.sh

	then copy the file to /usr/sbin/ folder

	now you can open your terminal and type the name of the file and hit enter, everything working 

By: Logan
